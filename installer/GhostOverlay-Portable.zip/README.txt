﻿# GhostOverlay - Portable Edition

## Installation

1. Extract all files to a folder of your choice
2. Run GhostOverlay.exe

## Configuration

Settings are stored in: %AppData%\GhostOverlay\appsettings.json

## Uninstallation

Simply delete the application folder.

## Requirements

- Windows 10 or later (64-bit)
- No additional runtime required (self-contained)

## Usage

- **Show/Hide Overlay:** Ctrl+Shift+O (default hotkey)
- **Add Monitor:** Click the âž• button
- **Settings:** Click the âš™ button

## Support

For issues and updates, visit:
https://github.com/ghostoverlay/ghostoverlay
